from pathlib import Path
import json
import sqlite3

from flask import Flask, jsonify, render_template, request
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "cookieslm.db"

app = Flask(__name__)

STAFF_ACCOUNTS = {
    "admin@cookieslm.com": {
        "password_hash": generate_password_hash("admin123"),
        "role": "Administrador",
        "name": "Admin",
    },
    "vendedor@cookieslm.com": {
        "password_hash": generate_password_hash("vendedor123"),
        "role": "Vendedor",
        "name": "Vendedor",
    },
}


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_column(conn, table, column, definition):
    columns = [row[1] for row in conn.execute(f"PRAGMA table_info({table})")]
    if column not in columns:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def init_db():
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                senha_hash TEXT NOT NULL,
                telefone TEXT DEFAULT '',
                cidade TEXT DEFAULT '',
                criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        ensure_column(conn, "clientes", "telefone", "TEXT DEFAULT ''")
        ensure_column(conn, "clientes", "cidade", "TEXT DEFAULT ''")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS pedidos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_nome TEXT NOT NULL,
                cliente_email TEXT NOT NULL,
                itens_json TEXT NOT NULL,
                total REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'Pendente',
                criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


@app.before_request
def preparar_banco():
    init_db()


@app.route("/")
def index():
    return render_template("index.html")


def cadastrar_cliente(nome, email, senha, telefone="", cidade=""):
    email = email.strip().lower()
    senha_hash = generate_password_hash(senha)
    with get_db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO clientes (nome, email, senha_hash, telefone, cidade)
            VALUES (?, ?, ?, ?, ?)
            """,
            (nome, email, senha_hash, telefone, cidade),
        )
    return cursor.lastrowid


@app.post("/api/cadastro")
def cadastro():
    data = request.get_json(silent=True) or {}
    nome = (data.get("nome") or "").strip()
    email = (data.get("email") or "").strip().lower()
    senha = (data.get("senha") or "").strip()
    telefone = (data.get("telefone") or "").strip()
    cidade = (data.get("cidade") or "").strip()

    if not nome or not email or not senha:
        return jsonify({"erro": "Preencha nome, e-mail e senha."}), 400
    if len(senha) < 4:
        return jsonify({"erro": "A senha precisa ter pelo menos 4 caracteres."}), 400
    if email in STAFF_ACCOUNTS:
        return jsonify({"erro": "Este e-mail ja esta reservado para a equipe."}), 400

    try:
        cliente_id = cadastrar_cliente(nome, email, senha, telefone, cidade)
    except sqlite3.IntegrityError:
        return jsonify({"erro": "Este e-mail ja esta cadastrado."}), 400

    return jsonify({
        "sucesso": True,
        "id": cliente_id,
        "nome": nome,
        "email": email,
        "telefone": telefone,
        "cidade": cidade,
        "role": "Cliente",
    })


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    senha = (data.get("senha") or "").strip()

    if not email or not senha:
        return jsonify({"erro": "Preencha e-mail e senha."}), 400

    staff = STAFF_ACCOUNTS.get(email)
    if staff:
        if not check_password_hash(staff["password_hash"], senha):
            return jsonify({"erro": "Senha de vendedor/administrador incorreta."}), 401
        return jsonify({
            "sucesso": True,
            "nome": staff["name"],
            "email": email,
            "role": staff["role"],
        })

    with get_db() as conn:
        cliente = conn.execute(
            "SELECT nome, email, senha_hash FROM clientes WHERE email = ?",
            (email,),
        ).fetchone()

    if not cliente:
        return jsonify({"erro": "Conta nao encontrada. Cadastre-se primeiro."}), 404
    if not check_password_hash(cliente["senha_hash"], senha):
        return jsonify({"erro": "Senha de cliente incorreta."}), 401

    return jsonify({
        "sucesso": True,
        "nome": cliente["nome"],
        "email": cliente["email"],
        "role": "Cliente",
    })


@app.get("/api/clientes")
def listar_clientes():
    with get_db() as conn:
        clientes = conn.execute(
            """
            SELECT id, nome, email, telefone, cidade, criado_em
            FROM clientes
            ORDER BY id DESC
            """
        ).fetchall()

    return jsonify([
        {
            "id": cliente["id"],
            "nome": cliente["nome"],
            "email": cliente["email"],
            "telefone": cliente["telefone"],
            "cidade": cliente["cidade"],
            "criado_em": cliente["criado_em"],
        }
        for cliente in clientes
    ])


@app.post("/api/clientes")
def criar_cliente_por_equipe():
    data = request.get_json(silent=True) or {}
    nome = (data.get("nome") or "").strip()
    email = (data.get("email") or "").strip().lower()
    telefone = (data.get("telefone") or "").strip()
    cidade = (data.get("cidade") or "").strip()
    senha = (data.get("senha") or "1234").strip()

    if not nome or not email:
        return jsonify({"erro": "Preencha nome e e-mail."}), 400
    if email in STAFF_ACCOUNTS:
        return jsonify({"erro": "Este e-mail ja esta reservado para a equipe."}), 400

    try:
        cliente_id = cadastrar_cliente(nome, email, senha, telefone, cidade)
    except sqlite3.IntegrityError:
        return jsonify({"erro": "Este e-mail ja esta cadastrado."}), 400

    return jsonify({
        "sucesso": True,
        "id": cliente_id,
        "nome": nome,
        "email": email,
        "telefone": telefone,
        "cidade": cidade,
    })


@app.get("/api/pedidos")
def listar_pedidos():
    with get_db() as conn:
        pedidos = conn.execute(
            """
            SELECT id, cliente_nome, cliente_email, itens_json, total, status, criado_em
            FROM pedidos
            ORDER BY id DESC
            """
        ).fetchall()

    return jsonify([
        {
            "id": pedido["id"],
            "cliente_nome": pedido["cliente_nome"],
            "cliente_email": pedido["cliente_email"],
            "itens": json.loads(pedido["itens_json"]),
            "total": pedido["total"],
            "status": pedido["status"],
            "criado_em": pedido["criado_em"],
        }
        for pedido in pedidos
    ])


@app.post("/api/pedidos")
def criar_pedido():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    itens = data.get("itens") or []

    if not email:
        return jsonify({"erro": "Faça login para finalizar o pedido."}), 400
    if not itens:
        return jsonify({"erro": "O carrinho esta vazio."}), 400

    with get_db() as conn:
        cliente = conn.execute(
            "SELECT nome, email FROM clientes WHERE email = ?",
            (email,),
        ).fetchone()

        if not cliente:
            return jsonify({"erro": "Cliente nao encontrado no banco."}), 404

        total = sum(float(item.get("price", 0)) * int(item.get("qty", 0)) for item in itens)
        pedido_itens = [
            {
                "name": item.get("name", "Cookie"),
                "price": float(item.get("price", 0)),
                "qty": int(item.get("qty", 0)),
            }
            for item in itens
        ]
        cursor = conn.execute(
            """
            INSERT INTO pedidos (cliente_nome, cliente_email, itens_json, total, status)
            VALUES (?, ?, ?, ?, 'Pendente')
            """,
            (cliente["nome"], cliente["email"], json.dumps(pedido_itens, ensure_ascii=False), total),
        )

    return jsonify({
        "sucesso": True,
        "id": cursor.lastrowid,
        "cliente_nome": cliente["nome"],
        "cliente_email": cliente["email"],
        "itens": pedido_itens,
        "total": total,
        "status": "Pendente",
    })


@app.patch("/api/pedidos/<int:pedido_id>")
def atualizar_status_pedido(pedido_id):
    data = request.get_json(silent=True) or {}
    novo_status = (data.get("status") or "").strip()

    status_validos = ["Pendente", "Em andamento", "Entregue", "Cancelado"]
    if novo_status not in status_validos:
        return jsonify({"erro": f"Status inválido. Use: {', '.join(status_validos)}"}), 400

    with get_db() as conn:
        resultado = conn.execute(
            "UPDATE pedidos SET status = ? WHERE id = ?",
            (novo_status, pedido_id),
        )
        if resultado.rowcount == 0:
            return jsonify({"erro": "Pedido não encontrado."}), 404

    return jsonify({"sucesso": True, "id": pedido_id, "status": novo_status})


if __name__ == "__main__":
    init_db()
    app.run(debug=True)

﻿# Loja CookiesLM com Flask + SQLite

## Como rodar

1. Abra o terminal nesta pasta.
2. Instale o Flask:

```bash
pip install -r requirements.txt
```

3. Rode o servidor:

```bash
python app.py
```

4. Abra no navegador:

```txt
http://localhost:5000
```

## Contas da equipe

- Administrador: admin@cookieslm.com / admin123
- Vendedor: vendedor@cookieslm.com / vendedor123

## Onde ficam os cadastros?

Os clientes cadastrados ficam no arquivo `cookieslm.db`, criado automaticamente quando o servidor roda.
